# 0 Gone Cooperative
 Gwen's Gone Cooperative Traits
