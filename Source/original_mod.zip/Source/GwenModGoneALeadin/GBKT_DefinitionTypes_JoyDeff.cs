﻿using RimWorld;

namespace GBKT_DefinitionTypes;

[DefOf]
public static class GBKT_DefinitionTypes_JoyDeff
{
    public static JoyKindDef Meditative;
}