﻿using RimWorld;

namespace GBKT_DefinitionTypes;

[DefOf]
public static class GBTK_DefinitionTypes_JobDeff
{
}